#train.py

import torch
import torch.nn as nn
from torchvision import transforms, datasets
import json
import matplotlib.pyplot as plt
import os
import torch.optim as optim
from Res import resnet50
import torchvision.models.resnet
import time
# import pandas as pd
from Res import confusion_matrix
import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(device)

data_transform = {
    "train": transforms.Compose([transforms.RandomResizedCrop(224),
                                 transforms.RandomHorizontalFlip(),
                                 transforms.ToTensor(),
                                 transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])]),#来自官网参数
    "val": transforms.Compose([transforms.Resize(256),#将最小边长缩放到256
                               transforms.CenterCrop(224),
                               transforms.ToTensor(),
                               transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])}


# data_root = os.getcwd()
data_root = r'./root_data'
image_path = data_root + "/test_mini/"  # flower data set pat b'vh

train_dataset = datasets.ImageFolder(root=image_path + "train",
                                     transform=data_transform["train"])
train_num = len(train_dataset)

# {'daisy':0, 'dandelion':1, 'roses':2, 'sunflower':3, 'tulips':4}
flower_list = train_dataset.class_to_idx
cla_dict = dict((val, key) for key, val in flower_list.items())
# write dict into json file
json_str = json.dumps(cla_dict, indent=4)
with open('class_indices50.json', 'w') as json_file:
    json_file.write(json_str)

batch_size =16
train_loader = torch.utils.data.DataLoader(train_dataset,
                                           batch_size=batch_size, shuffle=True,
                                           num_workers=0)

validate_dataset = datasets.ImageFolder(root=image_path + "/val",
                                        transform=data_transform["val"])
val_num = len(validate_dataset)
validate_loader = torch.utils.data.DataLoader(validate_dataset,
                                              batch_size=batch_size, shuffle=False,
                                             num_workers=0)
#从头训练
# net = resnet50(num_classes=2)
# optimizer = optim.Adam(net.parameters(), lr=0.0001)
##迁移学习
net = resnet50(pretrained=True)
# load pretrain weights 可以先下载模型参数，也可以直接加载，直接加载见pretrained=True。
# model_weight_path = "./resnet34-pre.pth"
# missing_keys, unexpected_keys = net.load_state_dict(torch.load(model_weight_path), strict=False)#载入模型参数
#如果只是最后一层进行优化，只需要param.requires_grad = False
# for param in net.parameters():
#     param.requires_grad = False

# 修改模型最后一层的结构，调整自己的分类数。change fc layer structure
inchannel = net.fc.in_features
net.fc = nn.Linear(inchannel, 3)

####  选择模型所有层都要进行反向传播优化 还是 只优化最优一层  #####
fullretrain = True  # True: 表示所有层都要进行优化，为False: 只优化最后一层

if fullretrain:
    print("=> optimizing all layers")
    for param in net.parameters():
        param.requires_grad = True
    optimizer = optim.Adam(net.parameters(), lr=0.0001, weight_decay=1e-4)
        # model.parameters()： 把模型所有参数都传进去
else:
    print("=> optimizing fc/classifier layers")
    optimizer = optim.Adam(net.module.fc.parameters(), lr=0.0001, weight_decay=1e-4)
    # model.module.fc.parameters()： 只传最后一个分类层的参数进去
    # 注意： 不同模型，最后一层的名字不一样
                                              
net.to(device)
loss_function = nn.CrossEntropyLoss()
                                              


 
train_loss = []
train_accurate = []
val_loss = []
val_accurate = []
precision=[]
recall=[]
F1_score=[]

n = 2#设置总分类数
best_acc = 0.0
best_F1_score=0.0
save_path = './resNet50.pth'
save_matrix_path='./matrix.txt'
for epoch in range(120):
    # train
    net.train()
    running_loss = 0.0
    running_corrects=0.0
    t1 = time.perf_counter()
    for step, data in enumerate(train_loader, start=0):
        images, labels = data
        optimizer.zero_grad()
        
        logits = net(images.to(device))
        loss = loss_function(logits, labels.to(device))
        loss.backward()
        optimizer.step()
        # print statistics
        running_loss += loss.item()
         # eval model only have last output layer
        predict_y = torch.max(logits, dim=1)[1]
        running_corrects += (predict_y == labels.to(device)).sum().item()

        # print train process
        rate = (step+1)/len(train_loader)
        a = "*" * int(rate * 50)
        b = "." * int((1 - rate) * 50)
        print("\rtrain loss: {:^3.0f}%[{}->{}]{:.4f}".format(int(rate*100), a, b, loss), end="")
    train_accurate_ = running_corrects / train_num
    train_loss_ = running_loss / step
    train_loss.append(train_loss_)
    train_accurate.append(train_accurate_)
    print()
    

    # validate
    net.eval()
    acc = 0.0  # accumulate accurate number / epoch
    val_loss_ = 0.0
    conf_matrix = torch.zeros(n, n)
    with torch.no_grad():
        for step, val_data in enumerate(validate_loader, start=0):
            val_images, val_labels = val_data
            outputs = net(val_images.to(device))  # eval model only have last output layer
            loss = loss_function(outputs, val_labels.to(device))
            val_loss_ += loss.item()
            predict_y = torch.max(outputs, dim=1)[1]
#             acc += (predict_y == val_labels.to(device)).sum().item()
            
            conf_matrix = np.array(confusion_matrix(predict_y, val_labels.to(device), conf_matrix))
#             conf_matrix_1=np.array(conf_matrix)
            corrects=conf_matrix.diagonal(offset=0)#抽取对角线的每种分类的识别正确个数
            cor_number = conf_matrix.diagonal(offset=0).sum()#预测正确的样本数
            totle_number = conf_matrix.sum()#总样本数
            real_totle=conf_matrix.sum(axis=1)#该样本真实值总样本
            pre_totle=conf_matrix.sum(axis=0)#该样本预测值总样本
            
            precision_=[rate for rate in corrects/pre_totle]#精确度
            recall_=[rate for rate in corrects/real_totle]#召回率
            accuracy_ = cor_number/totle_number
            F1_score_ =np.array([2*precision[i]*recall[i]/(precision[i]+recall[i]) for i in range(n)]).sum()/n 
            
        val_loss_ = val_loss_ / step
#         val_accurate_ = acc / val_num
#         val_accurate.append(val_accurate_)
        val_accurate.append(accuracy_)
        val_loss.append(val_loss_)
        precision.append(precision_)
        recall.append(recall_)
        F1_score.append(F1_score_)
        
#         if val_accurate_ > best_acc:
#             best_acc = val_accurate_
#             torch.save(net.state_dict(), save_path)
            
#             np.savetxt('data10matrix.txt',conf_matrix_1, fmt="%d", delimiter=',')
            
        if F1_score_ > best_F1_score:
            best_F1_score=F1_score_
            torch.save(net.state_dict(), save_path)
            np.savetxt(save_matrix_path,conf_matrix, fmt="%d", delimiter=',')
            
        print('[epoch %d] train_loss: %.3f train_accuracy:%.3f  test_loss: %.3f test_accuracy: %.3f precision:%.3f recall:%.3f F1_score:%.3f'%
              (epoch + 1, train_loss_, train_accurate_, val_loss_, val_accurate_,precision_,recall_,F1_score_))
    print(time.perf_counter() - t1)
print('Finished Training')

dict = {'train_loss':train_loss, 'train_accurate':train_accurate, 'val_loss':val_loss, 'val_accurate':val_accurate, 'precision':precision, 'recall':recall, 'F1_score':F1_score}
df = pd.DataFrame(dict)
df.to_excel(r'./loss15.xlsx',index = 0)
print('Finished Training')
